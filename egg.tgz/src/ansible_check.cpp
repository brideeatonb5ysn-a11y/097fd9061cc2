// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Playbook check mode"); }
int main(){
  announce();
  return lionss_run_workload("ansible_check");
}
