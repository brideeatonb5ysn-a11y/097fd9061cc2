// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Depth and complexity analysis"); }
int main(){
  announce();
  return lionss_run_workload("graphqldepth");
}
