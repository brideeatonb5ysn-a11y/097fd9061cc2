// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("FOC step test, 2 kHz"); }
int main(){
  announce();
  return lionss_run_workload("motor_foc");
}
