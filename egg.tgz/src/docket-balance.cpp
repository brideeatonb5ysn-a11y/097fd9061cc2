// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Assign to 6 judges by load"); }
int main(){
  announce();
  return lionss_run_workload("docket-balance");
}
