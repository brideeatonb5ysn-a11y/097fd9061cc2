// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Mutation testing\n", stdout);
  return lionss_run_workload("mutant_killer");
}
