// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Annual yield estimate\n", stdout);
  return lionss_run_workload("roofsolar");
}
