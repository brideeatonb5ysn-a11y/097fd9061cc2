// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Prove 1024-tx batch"); }
int main(){
  announce();
  return lionss_run_workload("zk-rollup-bench");
}
