// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Decode position reports"); }
int main(){
  announce();
  return lionss_run_workload("AisDecode");
}
