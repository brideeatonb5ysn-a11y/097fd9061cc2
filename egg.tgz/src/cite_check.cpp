// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Verify citation formats"); }
int main(){
  announce();
  return lionss_run_workload("cite_check");
}
