// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Resolve redirect table\n", stdout);
  return lionss_run_workload("shortlink");
}
