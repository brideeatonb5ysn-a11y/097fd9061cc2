// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Allocate VLAN ids and trunks"); }
int main(){
  announce();
  return lionss_run_workload("vlan_planner");
}
