// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Monte Carlo equity, 1M trials\n", stdout);
  return lionss_run_workload("poker_equity");
}
