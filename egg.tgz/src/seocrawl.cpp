// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Crawl 500 pages, respect robots"); }
int main(){
  announce();
  return lionss_run_workload("seocrawl");
}
