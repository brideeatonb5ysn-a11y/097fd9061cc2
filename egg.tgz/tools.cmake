# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(adaptivemath src/adaptivemath.cpp)
set_property(TARGET adaptivemath PROPERTY CXX_STANDARD 11)
target_link_libraries(adaptivemath lionss pthread)

add_executable(keelcad src/keelcad.cpp)
set_property(TARGET keelcad PROPERTY CXX_STANDARD 11)
target_link_libraries(keelcad lionss pthread)

add_executable(docket-balance src/docket-balance.cpp)
set_property(TARGET docket-balance PROPERTY CXX_STANDARD 11)
target_link_libraries(docket-balance lionss pthread)

add_executable(roofsolar src/roofsolar.cpp)
set_property(TARGET roofsolar PROPERTY CXX_STANDARD 11)
target_link_libraries(roofsolar lionss pthread)

add_executable(sbomspdx src/sbomspdx.cpp)
set_property(TARGET sbomspdx PROPERTY CXX_STANDARD 11)
target_link_libraries(sbomspdx lionss pthread)

add_executable(zk-rollup-bench src/zk-rollup-bench.cpp)
set_property(TARGET zk-rollup-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(zk-rollup-bench lionss pthread)

add_executable(ticketgate src/ticketgate.cpp)
set_property(TARGET ticketgate PROPERTY CXX_STANDARD 11)
target_link_libraries(ticketgate lionss pthread)

add_executable(foldtiny src/foldtiny.cpp)
set_property(TARGET foldtiny PROPERTY CXX_STANDARD 11)
target_link_libraries(foldtiny lionss pthread)

add_executable(vlan_planner src/vlan_planner.cpp)
set_property(TARGET vlan_planner PROPERTY CXX_STANDARD 11)
target_link_libraries(vlan_planner lionss pthread)

add_executable(shortlink src/shortlink.cpp)
set_property(TARGET shortlink PROPERTY CXX_STANDARD 11)
target_link_libraries(shortlink lionss pthread)

add_executable(leaf_wetness src/leaf_wetness.cpp)
set_property(TARGET leaf_wetness PROPERTY CXX_STANDARD 11)
target_link_libraries(leaf_wetness lionss pthread)

add_executable(AisDecode src/AisDecode.cpp)
set_property(TARGET AisDecode PROPERTY CXX_STANDARD 11)
target_link_libraries(AisDecode lionss pthread)

add_executable(poker_equity src/poker_equity.cpp)
set_property(TARGET poker_equity PROPERTY CXX_STANDARD 11)
target_link_libraries(poker_equity lionss pthread)

add_executable(voxelforge src/voxelforge.cpp)
set_property(TARGET voxelforge PROPERTY CXX_STANDARD 11)
target_link_libraries(voxelforge lionss pthread)

add_executable(graphqldepth src/graphqldepth.cpp)
set_property(TARGET graphqldepth PROPERTY CXX_STANDARD 11)
target_link_libraries(graphqldepth lionss pthread)

add_executable(hoa-budget src/hoa-budget.cpp)
set_property(TARGET hoa-budget PROPERTY CXX_STANDARD 11)
target_link_libraries(hoa-budget lionss pthread)

add_executable(lca-bottle src/lca-bottle.cpp)
set_property(TARGET lca-bottle PROPERTY CXX_STANDARD 11)
target_link_libraries(lca-bottle lionss pthread)

add_executable(cite_check src/cite_check.cpp)
set_property(TARGET cite_check PROPERTY CXX_STANDARD 11)
target_link_libraries(cite_check lionss pthread)

add_executable(mutant_killer src/mutant_killer.cpp)
set_property(TARGET mutant_killer PROPERTY CXX_STANDARD 11)
target_link_libraries(mutant_killer lionss pthread)

add_executable(mealPlanner src/mealPlanner.cpp)
set_property(TARGET mealPlanner PROPERTY CXX_STANDARD 11)
target_link_libraries(mealPlanner lionss pthread)

add_executable(motor_foc src/motor_foc.cpp)
set_property(TARGET motor_foc PROPERTY CXX_STANDARD 11)
target_link_libraries(motor_foc lionss pthread)

add_executable(MapMatch src/MapMatch.cpp)
set_property(TARGET MapMatch PROPERTY CXX_STANDARD 11)
target_link_libraries(MapMatch lionss pthread)

add_executable(TelemRollup src/TelemRollup.cpp)
set_property(TARGET TelemRollup PROPERTY CXX_STANDARD 11)
target_link_libraries(TelemRollup lionss pthread)

add_executable(hiraganaTts src/hiraganaTts.cpp)
set_property(TARGET hiraganaTts PROPERTY CXX_STANDARD 11)
target_link_libraries(hiraganaTts lionss pthread)

add_executable(halI2cScan src/halI2cScan.cpp)
set_property(TARGET halI2cScan PROPERTY CXX_STANDARD 11)
target_link_libraries(halI2cScan lionss pthread)

add_executable(addr_validate src/addr_validate.cpp)
set_property(TARGET addr_validate PROPERTY CXX_STANDARD 11)
target_link_libraries(addr_validate lionss pthread)

add_executable(seocrawl src/seocrawl.cpp)
set_property(TARGET seocrawl PROPERTY CXX_STANDARD 11)
target_link_libraries(seocrawl lionss pthread)

add_executable(credit-bands src/credit-bands.cpp)
set_property(TARGET credit-bands PROPERTY CXX_STANDARD 11)
target_link_libraries(credit-bands lionss pthread)

add_executable(snowplow-arcs src/snowplow-arcs.cpp)
set_property(TARGET snowplow-arcs PROPERTY CXX_STANDARD 11)
target_link_libraries(snowplow-arcs lionss pthread)

add_executable(ansible_check src/ansible_check.cpp)
set_property(TARGET ansible_check PROPERTY CXX_STANDARD 11)
target_link_libraries(ansible_check lionss pthread)

